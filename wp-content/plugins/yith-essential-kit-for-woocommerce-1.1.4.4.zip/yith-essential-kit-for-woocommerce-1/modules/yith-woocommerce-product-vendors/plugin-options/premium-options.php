<?php

return array(
	'premium' => array(
		'home' => array(
			'type'   => 'custom_tab',
			'action' => 'yith_wc_multi_vendor_premium_tab',
		)
	)
);