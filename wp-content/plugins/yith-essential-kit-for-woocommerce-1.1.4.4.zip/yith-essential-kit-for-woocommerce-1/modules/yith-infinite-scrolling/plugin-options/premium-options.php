<?php

return array(
	'premium' => array(
		'home' => array(
			'type'   => 'custom_tab',
			'action' => 'yith_infinite_scrolling_premium'
		)
	)
);