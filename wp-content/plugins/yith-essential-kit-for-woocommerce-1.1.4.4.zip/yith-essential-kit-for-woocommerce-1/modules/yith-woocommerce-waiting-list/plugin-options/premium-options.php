<?php

return array(
	'premium' => array(
		'home' => array(
			'type'   => 'custom_tab',
			'action' => 'yith_waiting_list_premium',
		)
	)
);