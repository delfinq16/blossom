<div id="woocommerce-cart-notice-name" class="woocommerce-cart-notice woocommerce-cart-notice-minimum-amount woocommerce-info">
    <?php echo  $text.' '.$button  ?>
</div>