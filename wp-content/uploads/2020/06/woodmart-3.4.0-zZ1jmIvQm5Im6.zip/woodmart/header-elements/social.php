<?php 
	$params['style'] = ( ! $params['style'] ) ? 'default' : $params['style'];
	echo woodmart_shortcode_social($params);
?>