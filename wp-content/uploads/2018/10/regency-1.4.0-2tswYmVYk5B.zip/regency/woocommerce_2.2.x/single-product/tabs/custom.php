<?php
/*
 * Custom Tabs
 */

echo yit_addp( $tab['custom_tab']["value"] );

?>