<?php 
	echo woodmart_shortcode_info_box($params, $params['content']);
?>